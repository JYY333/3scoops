<style>[df-banner-code][hidden] { display:none !important }</style>
<script>
$DF.ajax({
	type: 'GET',
	url: '/web/upload/appfiles/ZaReJam3QiELznoZeGGkMG/c14de46baa5033dd5ddf97b81314cb09.js?v=1'+Math.random(),
	dataType: 'script',
	async: false,
});
</script>
    
<!-- ADN 메인패널 설치 start -->
<script type="text/javascript">
var adn_mobile_pinad_param = adn_mobile_pinad_param || [];
adn_mobile_pinad_param.push([{
 ui:'103582',	
 ci:'1035820002',
 gi:'47453'
}]);
</script>
<script type="text/javascript" async src="//fin.rainbownine.net/js/across_adn_mainpanel_mobile_ad_1.0.4_3.js"></script>
<!-- ADN 메인패널 설치 end -->
    
<span itemscope="" itemtype="https://schema.org/Organization">
<link itemprop="url" href="https://diverfishery.com">
<a itemprop="sameAs" href="www.instagram.com/diversusan_"></a>
<a itemprop="sameAs" href="https://www.facebook.com/diverfishery/"></a>
<a itemprop="sameAs" href="https://www.youtube.com/c/다이버수산TV"></a>
</span>

                <script>
                try {
                    // Account ID 적용
                    if (!wcs_add) var wcs_add = {};
                    wcs_add["wa"] = "s_52009869b30f";
            
                    // 마일리지 White list가 있을 경우
                    wcs.mileageWhitelist = ["ekdlqjtntks.cafe24.com", "www.ekdlqjtntks.cafe24.com", "m.ekdlqjtntks.cafe24.com", "diverfishery.com", "www.diverfishery.com", "m.diverfishery.com", "다이버수산.com", "www.다이버수산.com", "m.다이버수산.com"];

                    // 네이버 페이 White list가 있을 경우
                    wcs.checkoutWhitelist = ["ekdlqjtntks.cafe24.com", "www.ekdlqjtntks.cafe24.com", "m.ekdlqjtntks.cafe24.com", "diverfishery.com", "www.diverfishery.com", "m.diverfishery.com", "다이버수산.com", "www.다이버수산.com", "m.다이버수산.com"];
                
                    // 레퍼러 (스크립트 인젠션 공격 대응 strip_tags) ECQAINT-15101
                    wcs.setReferer("");

                    // 유입 추적 함수 호출
                    wcs.inflow("diverfishery.com");

                    // 로그수집
                    wcs_do();
                } catch (e) {};
                </script>
            

<!-- External Script Start -->

<!-- fbe -->
<!-- CMC3 script -->
<div id="fbe_common_top_script" style="display:none;">
  <script type="text/javascript">
if(! window.top.fbe_init_activated) {
  !function(){
    function get_cookie(name) {
      return (name = (document.cookie + ';').match(name + '=.*;')) && name[0].split(/=|;/)[1];
    }
    function get_external_id(){
      return get_cookie('fb_external_id');
    }

    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window, document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
    fbq('dataProcessingOptions', ['LDU'], 0, 0);
    fbq('init', '985634732279286',{external_id: get_external_id()}, {agent: 'plcafe24'});
    fbq('trackSingle', '985634732279286', 'PageView');
  }();
  window.top.fbe_init_activated = true;
}
</script>
</div>
<!-- CMC3 script -->

<!-- External Script End -->

<script type="text/javascript" src="//developers.kakao.com/sdk/js/kakao.min.js" charset="utf-8"></script>
<script type="text/javascript" src="/ind-script/i18n.php?lang=ko_KR&domain=front&v=2212151160" charset="utf-8"></script>

<script src="/ind-script/optimizer.php?filename=zVldU-M2FH2HvPZ3uLSdTl9JWFqmUBhgl2dZvk4uliVVH4Tsr--Vnd0lgGVbNjMdhsR2dM6Vr879kJ1tVA3ZyS8mKw2rYatMlRmwyhsO2aPN8OQPuXi0P2WxcR4141X2-K8Hs9t__br4ffHzSCQ8OzCSCbu_sOBKVQhTWbwRSbewAL4oZTJUKq5kKZC7JIqTxW_0l2ScfnXKvPKbNmpN-IPVLZgDhzSgplHSZcCvmoMHdJv7r2fMsUWNcgSPwJxQcE_H_SirDUpXDqBX3IdpnStTr5R0RgkBph93I7w91XppsFgPmI93KPpHlUY1njqyShBCySOn9JFACUc5k3LIvFoKrupayaGjn5mkaJQkbW3ADbfS4BzUWtC6vA9iWmdXKkcB2e0LfDu_iFc6cLUqPF2yW9TjDJZe8uDQMK7wFDZ1p4iHMkQmQVLNPrfR85JCsK87oVgxClR7x4Ld69yCeepanA6wVmJXohgsvQJK5oULLrA1M24ZUV0YdLdR-sDgeUPzN6uYyqrweYPPIGJREqFZNSr5HBVJB_QWSjAgOay8Cd-7G4N8crbP19iA_h-1p6BMKC1Jw05lAmZRrqey1OBYEfL6mLAKl8PY3DvXlbFiEqHMs1Zmd4nWdYOXipnitdlFHq6OtmiBGb4ZFYWOleXubbXr9bAWfo2UYp-YQHKsMt88_f3Cgg6YnUwbllIW9i09MWjSF3ychQ0IDR9-HxsmizdlfU4DlJiR1vjD-CmJu9ncJBRnFIaV6i8LP2YwNk7-gW34v2mr5bUONewOBHCXRLX3yKNNSBKv8e94cfgNXQtZJWFbF2Sfnp1hDVFz3pzeKVEo7-amfafmTSe9qNl6dtIztNRE7pCayRmpL4jujgqbgFZ4mKid6MQNES-ZrWD25Tv3snhTlqfTPtR2CuV3slVkjzGaSs4zpyXKYhais2gfM4LoS5tAO6XX0TJ8a1szS6aOdXcgD8Lz_dlxSbtc5qbOZC4an9LZH9aVeN83iOI0PTH8ILlziqeVhUusIFsataXt3YrxDaSzTIjIF_j9HY2m2eOyM9oGoMiWPrRcdLFWyf69hSeErWOi2h-ulJeJfb7nPA2Yi-jSxqAiqLNuNj2RTRGTVFEPGLZARtf93dnG1QKkQ4dgRxlgdid5-5mMq6HOY88GeuDXpgDDY6vZQ9AW3ekMOt4lDeLojZkeFtI17bOm3MsVaSzamPXgz0Ari-n2H9Bu4sl4AAGPh3cPA3ViMAF-28DvFaWb1aR5NMpOFxRIKHGqqC_ZbsIc_jSsSJfSqXeK2gPkDQ2l9226qr1weKO01-kUu1Db9gE6bWEPqCaJ_RKfQKCsYnVxiMr-wvA2ZjeDXvdM9yyfhSdsvSZ5qCFrW4kLWar0zCoY1iwXMGFGmrmNUQKOBzwN6Vv4zsf_HWCdUFnaynxMLQRG9PVp__z28C1H03vRz5Yb1G4kOjyqz05DT6eBNy-USharre-SHKQSrVcDX2UZ5R2c4zON_A8&type=js&k=465489df43289848f930dc2927f518a4686b7cfc&t=1669680207" ></script><script src="/ind-script/optimizer.php?filename=tZKxVsMwDEX3pCvfoYmPYGDiCxxbTdTIlmrZtPw9OZBDKWvFZL3lPl_ZsEhGwDh2w2qAa-LzqZW2GmifmOK4tMxgCceERnOBLBMxPkM6skiFk0GUnKUcTvYEj9IMW1cX0navdByYJkeahayMLkDlPlMBvA71kl5ymPE1qMHvcMhUPLs2Aa2SemxM1v5E77JNjCxWYYb9_Aedc6e47i330a3s--GnYBQdebFbk-wCdETdFttEp1AK1rvwWMlmnrfvxggcPqQ3yJ0b2SL6tpAqldlTIqgOVKyFuYYMP5Pznr4UVLTrfXKuqfhOeLlN--_-BA&type=js&k=07d2edb8620bf9837f9d4c56cacae346d80d5739&t=1663822861&user=T" ></script>
<script type="text/javascript">
CAFE24.MOBILE_WEB = true; var mobileWeb = CAFE24.MOBILE_WEB;
try {
var isUseLoginKeepingSubmit = false;
// isSeqNoKeyExpiretime
function isSeqNoKeyExpiretime(iExpiretime)
{
var sDate = new Date();
var iNow = Math.floor(sDate.getTime() / 1000);
// 유효시간 확인
if (iExpiretime > iNow) {
return false;
}
return true;
}
function isUseLoginKeeping()
{
// 디바이스 확인
if (EC_MOBILE_DEVICE === false) {
return;
}
// 로그인 여부
if (sessionStorage.getItem('member_' + CAFE24.SDE_SHOP_NUM) !== null) {
return;
}
var sLoginKeepingInfo = localStorage.getItem('use_login_keeping_info');
var iSeqnoExpiretime;
var iSeqNoKey;
if (sLoginKeepingInfo == null) {
iSeqnoExpiretime = localStorage.getItem('seq_no_key_expiretime');
iSeqNoKey = localStorage.getItem('seq_no_key');
// 유효시간, key 값 확인
if (iSeqnoExpiretime === null || iSeqNoKey === null) {
return;
}
} else {
var oLoginKeepingInfo = JSON.parse(sLoginKeepingInfo);
iSeqNoKey = oLoginKeepingInfo.seq_no_key;
iSeqnoExpiretime = oLoginKeepingInfo.seq_no_key_expiretime;
if (isNaN(iSeqNoKey) === true || isNaN(iSeqnoExpiretime) === true) {
return;
}
}
if (isSeqNoKeyExpiretime(iSeqnoExpiretime) === false) {
return;
}
useLoginKeepingSubmit();
}
function findGetParamValue(paramKey) 
{
var result = null,
tmp = [];
location.search.substr(1).split('&').forEach(function (item) {
tmp = item.split('=');
if (tmp[0] === paramKey) result = decodeURIComponent(tmp[1]);
});
return result;
}
function useLoginKeepingSubmit()
{
var iSeqnoExpiretime;
var iSeqNoKey;
var sUseLoginKeepingIp;
var sLoginKeepingInfo = localStorage.getItem('use_login_keeping_info');
if (sLoginKeepingInfo == null) {
iSeqnoExpiretime = localStorage.getItem('seq_no_key_expiretime');
iSeqNoKey = localStorage.getItem('seq_no_key');
} else {
var oLoginKeepingInfo = JSON.parse(sLoginKeepingInfo);
iSeqNoKey = oLoginKeepingInfo.seq_no_key;
iSeqnoExpiretime = oLoginKeepingInfo.seq_no_key_expiretime;
sUseLoginKeepingIp = oLoginKeepingInfo.use_login_keeping_ip;
}
var oForm = document.createElement('form');
oForm.method = 'post';
oForm.action = '/exec/front/member/LoginKeeping';
document.body.appendChild(oForm);
var oSeqNoObj = document.createElement('input');
oSeqNoObj.name = 'seq_no_key';
oSeqNoObj.type = 'hidden';
oSeqNoObj.value = iSeqNoKey;
oForm.appendChild(oSeqNoObj);
oSeqNoObj = document.createElement('input');
oSeqNoObj.name = 'seq_no_key_expiretime';
oSeqNoObj.type = 'hidden';
oSeqNoObj.value = iSeqnoExpiretime;
oForm.appendChild(oSeqNoObj);
var returnUrl = findGetParamValue('returnUrl');
if (returnUrl == '' || returnUrl == null) {
returnUrl = location.pathname + location.search;
}
oSeqNoObj = document.createElement('input');
oSeqNoObj.name = 'returnUrl';
oSeqNoObj.type = 'hidden';
oSeqNoObj.value = returnUrl;
oForm.appendChild(oSeqNoObj);
if (sUseLoginKeepingIp != undefined) {
oSeqNoObj = document.createElement('input');
oSeqNoObj.name = 'use_login_keeping_ip';
oSeqNoObj.type = 'hidden';
oSeqNoObj.value = sUseLoginKeepingIp;
oForm.appendChild(oSeqNoObj);
}
oForm.submit();
isUseLoginKeepingSubmit = true;
}
isUseLoginKeeping();
} catch(e) {
}
var bUseElastic = false;
var aSearchBannerData = [{"msb_idx":9,"msb_prt_no":30,"msb_contents":"\ud788\ud2b8 \uc0c1\ud488 \ubc14\uc9c0\ub77d!","msb_type":"P","msb_cate_no":0,"msb_keyword":null,"msb_url":null,"product_name":"","category_name":null,"banner_action":"\/product\/detail.html?product_no=30"},{"msb_idx":10,"msb_prt_no":36,"msb_contents":"\uac04\ud3b8\ud55c\uc694\ub9ac \ubc14\ucb48\uc0bc \ubd88\uace0\uae30~!!","msb_type":"P","msb_cate_no":0,"msb_keyword":null,"msb_url":null,"product_name":"","category_name":null,"banner_action":"\/product\/detail.html?product_no=36"},{"msb_idx":11,"msb_prt_no":35,"msb_contents":"\uac74\uac15\uc774 \ucd5c\uace0!! \ud2b9\ub300 \uc544\ub77c\ud574\uc2e0\ud0d5~","msb_type":"P","msb_cate_no":0,"msb_keyword":null,"msb_url":null,"product_name":"","category_name":null,"banner_action":"\/product\/detail.html?product_no=35"},{"msb_idx":12,"msb_prt_no":38,"msb_contents":"\uc5b4\ub9b0\uc774 \ubc25\ubc18\ucc2c \ubc18\uac74\uc870 \ubc15\ub300~","msb_type":"P","msb_cate_no":0,"msb_keyword":null,"msb_url":null,"product_name":"","category_name":null,"banner_action":"\/product\/detail.html?product_no=38"}];
var sSearchBannerType = 'R';
var sSearchBannerUseFlag = 'T';
$Recentword.init();
CAFE24.FRONT_XANS_TEMPLATE.setTemplate('xans-product-listmain-1', "<div class=\"xans-element- xans-product xans-product-listmain-1 xans-product-listmain xans-product-1 df-content-wrap df-prl-wrap df-prl-setup\">\n<!--\n\t\t$count = 8\n\t\t\u203b\ud55c\ubc88\uc5d0 \ud45c\uc2dc\ud560 \uc0c1\ud488\uc218\ub97c \uc124\uc815\ud560 \uc218 \uc788\uc2b5\ub2c8\ub2e4. \uac1c\uc218\uac00 \ub9ce\uc73c\uba74 \ubd80\ud558\uac00 \ubc1c\uc0dd\ud558\uba70 \uc18d\ub3c4\uac00 \ub290\ub824\uc9c8 \uc218 \uc788\uc2b5\ub2c8\ub2e4.\n\n\t\t$cache = yes\n\t\t\u203b\uce90\uc2dc\ub97c \uc124\uc815\ud558\uba74 \ub354\ubcf4\uae30 \ubc84\ud2bc\uc744 \ud074\ub9ad\ud55c \ub9cc\ud07c \uc7ac\uc811\uc18d\uc2dc \uae30\uc5b5\ud569\ub2c8\ub2e4. yes \ub610\ub294 no\ub85c \uc124\uc815\ud558\uc138\uc694.\n\n\t\t$moreview = yes\n\t\t\u203b\ud574\ub2f9 \ubcc0\uc218\ub294 \uc218\uc815\ud558\uc9c0\ub9c8\uc138\uc694. \ub9e4\ub274\uc5bc\uc744 \ucc38\uace0\ud558\uc5ec \ub354\ubcf4\uae30 \ubc84\ud2bc\uc758 \ud45c\uc2dc\uc5ec\ubd80\ub97c \uc124\uc815\ud558\uc2dc\uae30 \ubc14\ub78d\ub2c8\ub2e4.\n\t-->\n<div class=\"tit-product-main\">\n\t\t<h2><span>{$category_title_text}<\/span><\/h2>\n\t\t<span style=\"display: {$category_title_img_display};\"><img src=\"{$category_title_img}\" class=\"imgtitle\"><\/span>\n\t<\/div>\n<ul class=\"df-prl-items df-items-standby\">\n<!--$--><!--@--><li class=\"df-prl-item\" id=\"anchorBoxId_{$product_no}\">\n<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d -->\n<div class=\"df-prl-box\">\n\t<span class=\"df-prl-label\"><\/span>\n\t<div class=\"df-prl-thumb\">\n\n\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uafb8\ubbf8\uae30\uc544\uc774\ucf58 \ud3ec\ud568 -->\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-thumb-link\" name=\"anchorBoxName_{$product_no}\"><img src=\"{$image_medium}\" id=\"{$image_medium_id}\" alt=\"{$seo_alt_tag}\" class=\"thumb\"><!--#--><span class=\"xans-element- xans-product xans-product-imagestyle-1 xans-product-imagestyle xans-product-1\">\n<span class=\"df-prl-decoicon {$icon_class_name}\" style=\"background-image:url('{$icon_url}');\"><\/span>\n<\/span>\n<!--#--><\/a>\n\n\t\t<!-- \uc88b\uc544\uc694 -->\n\t\t<span class=\"df-prl-like {$disp_likeprd_class} {$disp_likeprd_class|display}\">{$disp_likeprd_icon}{$disp_likeprd_count}<\/span>\n\n\t\t<!-- \ud560\uc778\uc728 -->\n\t\t<span class=\"df-prl-discountrate\">\n\t\t\t<span class=\"rate\"><\/span>%\n\t\t\t<span class=\"df-prl-data-custom displaynone\">{$product_custom}<\/span>\n\t\t\t<span class=\"df-prl-data-price displaynone\">{$product_price}<\/span>\n\t\t\t<span class=\"df-prl-data-sale displaynone\">{$prd_price_sale}<\/span>\n\t\t<\/span>\n\t<\/div>\n\t<div class=\"df-prl-timesale\" df-data-timesales=\"{$product_promotion_start_date}\" df-data-timesalee=\"{$product_promotion_end_date}\">\n<span class=\"before\"><\/span><span class=\"ing\"><\/span><span class=\"after\"><\/span>\n<\/div>\n\t<div class=\"df-prl-desc\">\n\t\t<div class=\"df-prl-fadearea\">\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uceec\ub7ec\uce69 -->\n\t\t\t<!--#--><div class=\"xans-element- xans-product xans-product-colorchip-1 xans-product-colorchip xans-product-1 color color-custom-wrap\">\n<!--$--><!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span>\n<!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span><!--$-->\n<\/div>\n<!--#-->\n\n\t\t\t<!-- \uc0c1\ud488\uba85 -->\n\t\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-name {$product_name_display|display}\" style=\"{$product_name_css}\">{$product_name}<\/a>\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uc0c1\ud488\ud56d\ubaa9 -->\n\t\t\t<!--#--><ul class=\"xans-element- xans-product xans-product-listitem-1 xans-product-listitem xans-product-1 df-prl-listitem\">\n<!--$--><!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--$-->\n<\/ul>\n<!--#--><!-- \uc0c1\ud488\uc544\uc774\ucf58 --><div class=\"df-prl-icon\">{$soldout_icon} {$stock_icon} {$recommend_icon} {$new_icon} {$product_icons} {$pickup_icon} {$benefit_icons}<\/div>\n\n\t\t\t<!-- \uc635\uc158\ubcf4\uae30\u00b7\uc7a5\ubc14\uad6c\ub2c8\u00b7\uad00\uc2ec\uc0c1\ud488\u00b7\uc0c8\ucc3d\ubcf4\uae30 -->\n\t\t\t<div class=\"df-prl-status\">\n\t\t\t\t<span class=\"df-prl-status-item basket {$basket_icon|display}\">{$basket_icon}<\/span>\n\t\t\t\t<span class=\"df-prl-status-item wish {$list_wish_icon|display}\">{$list_wish_icon}<\/span>\n\t\t\t<\/div>\n\n\t\t<\/div>\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-fadeboxlink\"><\/a>\n\t<\/div>\n<\/div>\n<\/li>\n\t\t<!--@--><li class=\"df-prl-item\" id=\"anchorBoxId_{$product_no}\">\n<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d -->\n<div class=\"df-prl-box\">\n\t<span class=\"df-prl-label\"><\/span>\n\t<div class=\"df-prl-thumb\">\n\n\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uafb8\ubbf8\uae30\uc544\uc774\ucf58 \ud3ec\ud568 -->\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-thumb-link\" name=\"anchorBoxName_{$product_no}\"><img src=\"{$image_medium}\" id=\"{$image_medium_id}\" alt=\"{$seo_alt_tag}\" class=\"thumb\"><!--#--><span class=\"xans-element- xans-product xans-product-imagestyle-1 xans-product-imagestyle xans-product-1\">\n<span class=\"df-prl-decoicon {$icon_class_name}\" style=\"background-image:url('{$icon_url}');\"><\/span>\n<\/span>\n<!--#--><\/a>\n\n\t\t<!-- \uc88b\uc544\uc694 -->\n\t\t<span class=\"df-prl-like {$disp_likeprd_class} {$disp_likeprd_class|display}\">{$disp_likeprd_icon}{$disp_likeprd_count}<\/span>\n\n\t\t<!-- \ud560\uc778\uc728 -->\n\t\t<span class=\"df-prl-discountrate\">\n\t\t\t<span class=\"rate\"><\/span>%\n\t\t\t<span class=\"df-prl-data-custom displaynone\">{$product_custom}<\/span>\n\t\t\t<span class=\"df-prl-data-price displaynone\">{$product_price}<\/span>\n\t\t\t<span class=\"df-prl-data-sale displaynone\">{$prd_price_sale}<\/span>\n\t\t<\/span>\n\t<\/div>\n\t<div class=\"df-prl-timesale\" df-data-timesales=\"{$product_promotion_start_date}\" df-data-timesalee=\"{$product_promotion_end_date}\">\n<span class=\"before\"><\/span><span class=\"ing\"><\/span><span class=\"after\"><\/span>\n<\/div>\n\t<div class=\"df-prl-desc\">\n\t\t<div class=\"df-prl-fadearea\">\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uceec\ub7ec\uce69 -->\n\t\t\t<!--#--><div class=\"xans-element- xans-product xans-product-colorchip-1 xans-product-colorchip xans-product-1 color color-custom-wrap\">\n<!--$--><!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span>\n<!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span><!--$-->\n<\/div>\n<!--#-->\n\n\t\t\t<!-- \uc0c1\ud488\uba85 -->\n\t\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-name {$product_name_display|display}\" style=\"{$product_name_css}\">{$product_name}<\/a>\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uc0c1\ud488\ud56d\ubaa9 -->\n\t\t\t<!--#--><ul class=\"xans-element- xans-product xans-product-listitem-1 xans-product-listitem xans-product-1 df-prl-listitem\">\n<!--$--><!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--$-->\n<\/ul>\n<!--#--><!-- \uc0c1\ud488\uc544\uc774\ucf58 --><div class=\"df-prl-icon\">{$soldout_icon} {$stock_icon} {$recommend_icon} {$new_icon} {$product_icons} {$pickup_icon} {$benefit_icons}<\/div>\n\n\t\t\t<!-- \uc635\uc158\ubcf4\uae30\u00b7\uc7a5\ubc14\uad6c\ub2c8\u00b7\uad00\uc2ec\uc0c1\ud488\u00b7\uc0c8\ucc3d\ubcf4\uae30 -->\n\t\t\t<div class=\"df-prl-status\">\n\t\t\t\t<span class=\"df-prl-status-item basket {$basket_icon|display}\">{$basket_icon}<\/span>\n\t\t\t\t<span class=\"df-prl-status-item wish {$list_wish_icon|display}\">{$list_wish_icon}<\/span>\n\t\t\t<\/div>\n\n\t\t<\/div>\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-fadeboxlink\"><\/a>\n\t<\/div>\n<\/div>\n<\/li>\n<!--$-->\n\t<\/ul>\n<!-- \ub354\ubcf4\uae30 \ubc84\ud2bc --><!--#--><div class=\"xans-element- xans-product xans-product-listmore-1 xans-product-listmore xans-product-1 df-prl-more df-use-prl-more\">\n<a href=\"#none\" onclick=\"{$more_action}\" class=\"df-prl-more-link\">\n\t\t\t<span class=\"df-prl-more-page df-use-prl-more-page\">\n\t\t\t\t<!--$--><!--@--><span id=\"more_current_page_{$display_group}\" class=\"df-prl-more-page-current\">{$current_page}<\/span>\n\t\t\t\t<!--@--><span id=\"more_total_page_{$display_group}\" class=\"df-prl-more-page-total\">{$total_page}<\/span><!--$-->\n\t\t\t<\/span>\n\t\t<\/a>\n<\/div>\n<!--#-->\n<\/div>\n");
if (typeof($M) !== 'undefined') {
$M.sModule = "xans-product-listmain";
$M.iCount = 0;
$M.iCategoryNo = 0;
$M.iSortMethod = 0;
$M.init();
}
CAFE24.SHOP_CURRENCY_INFO = {"1":{"aShopCurrencyInfo":{"currency_code":"KRW","currency_no":"410","currency_symbol":"\uffe6","currency_name":"South Korean won","currency_desc":"\uffe6 \uc6d0 (\ud55c\uad6d)","decimal_place":0,"round_method_type":"F"},"aShopSubCurrencyInfo":null,"aBaseCurrencyInfo":{"currency_code":"KRW","currency_no":"410","currency_symbol":"\uffe6","currency_name":"South Korean won","currency_desc":"\uffe6 \uc6d0 (\ud55c\uad6d)","decimal_place":0,"round_method_type":"F"},"fExchangeRate":1,"fExchangeSubRate":null,"aFrontCurrencyFormat":{"head":"","tail":"\uc6d0"},"aFrontSubCurrencyFormat":{"head":"","tail":""}}}; var SHOP_CURRENCY_INFO = CAFE24.SHOP_CURRENCY_INFO;
if (typeof CAFE24.SHOP_FRONT_NEW_OPTION_COMMON !== "undefined") {CAFE24.SHOP_FRONT_NEW_OPTION_COMMON.initObject();}
if (typeof CAFE24.SHOP_FRONT_NEW_OPTION_BIND !== "undefined") {CAFE24.SHOP_FRONT_NEW_OPTION_BIND.initChooseBox();}
if (typeof CAFE24.SHOP_FRONT_NEW_OPTION_DATA !== "undefined") {CAFE24.SHOP_FRONT_NEW_OPTION_DATA.initData();}
if (typeof CAFE24.SHOP_FRONT_NEW_LIKE_COMMON !== "undefined") {CAFE24.SHOP_FRONT_NEW_LIKE_COMMON.init({"bIsUseLikeProduct":true,"bIsUseLikeCategory":false});}
if (typeof CAFE24.SHOP_FRONT_REVIEW_TALK_REVIEW_COUNT !== "undefined") {CAFE24.SHOP_FRONT_REVIEW_TALK_REVIEW_COUNT.bIsReviewTalk = 'F';}
var basket_result = '/product/add_basket.html';
var basket_option = '/product/basket_option.html';
CAFE24.FRONT_XANS_TEMPLATE.setTemplate('xans-product-listmain-2', "<div class=\"xans-element- xans-product xans-product-listmain-2 xans-product-listmain xans-product-2 df-content-wrap df-prl-wrap df-prl-setup\">\n<!--\n\t\t$count = 12\n\t\t\u203b\ud55c\ubc88\uc5d0 \ud45c\uc2dc\ud560 \uc0c1\ud488\uc218\ub97c \uc124\uc815\ud560 \uc218 \uc788\uc2b5\ub2c8\ub2e4. \uac1c\uc218\uac00 \ub9ce\uc73c\uba74 \ubd80\ud558\uac00 \ubc1c\uc0dd\ud558\uba70 \uc18d\ub3c4\uac00 \ub290\ub824\uc9c8 \uc218 \uc788\uc2b5\ub2c8\ub2e4.\n\n\t\t$cache = yes\n\t\t\u203b\uce90\uc2dc\ub97c \uc124\uc815\ud558\uba74 \ub354\ubcf4\uae30 \ubc84\ud2bc\uc744 \ud074\ub9ad\ud55c \ub9cc\ud07c \uc7ac\uc811\uc18d\uc2dc \uae30\uc5b5\ud569\ub2c8\ub2e4. yes \ub610\ub294 no\ub85c \uc124\uc815\ud558\uc138\uc694.\n\n\t\t$moreview = yes\n\t\t\u203b\ud574\ub2f9 \ubcc0\uc218\ub294 \uc218\uc815\ud558\uc9c0\ub9c8\uc138\uc694. \ub9e4\ub274\uc5bc\uc744 \ucc38\uace0\ud558\uc5ec \ub354\ubcf4\uae30 \ubc84\ud2bc\uc758 \ud45c\uc2dc\uc5ec\ubd80\ub97c \uc124\uc815\ud558\uc2dc\uae30 \ubc14\ub78d\ub2c8\ub2e4.\n\t-->\n<div class=\"tit-product-main\">\n\t\t<h2><span>{$category_title_text}<\/span><\/h2>\n\t\t<span style=\"display: {$category_title_img_display};\"><img src=\"{$category_title_img}\" class=\"imgtitle\"><\/span>\n\t<\/div>\n<ul class=\"df-prl-items df-items-standby\">\n<!--$--><!--@--><li class=\"df-prl-item\" id=\"anchorBoxId_{$product_no}\">\n<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d -->\n<div class=\"df-prl-box\">\n\t<span class=\"df-prl-label\"><\/span>\n\t<div class=\"df-prl-thumb\">\n\n\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uafb8\ubbf8\uae30\uc544\uc774\ucf58 \ud3ec\ud568 -->\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-thumb-link\" name=\"anchorBoxName_{$product_no}\"><img src=\"{$image_medium}\" id=\"{$image_medium_id}\" alt=\"{$seo_alt_tag}\" class=\"thumb\"><!--#--><span class=\"xans-element- xans-product xans-product-imagestyle-2 xans-product-imagestyle xans-product-2\">\n<span class=\"df-prl-decoicon {$icon_class_name}\" style=\"background-image:url('{$icon_url}');\"><\/span>\n<\/span>\n<!--#--><\/a>\n\n\t\t<!-- \uc88b\uc544\uc694 -->\n\t\t<span class=\"df-prl-like {$disp_likeprd_class} {$disp_likeprd_class|display}\">{$disp_likeprd_icon}{$disp_likeprd_count}<\/span>\n\n\t\t<!-- \ud560\uc778\uc728 -->\n\t\t<span class=\"df-prl-discountrate\">\n\t\t\t<span class=\"rate\"><\/span>%\n\t\t\t<span class=\"df-prl-data-custom displaynone\">{$product_custom}<\/span>\n\t\t\t<span class=\"df-prl-data-price displaynone\">{$product_price}<\/span>\n\t\t\t<span class=\"df-prl-data-sale displaynone\">{$prd_price_sale}<\/span>\n\t\t<\/span>\n\t<\/div>\n\t<div class=\"df-prl-timesale\" df-data-timesales=\"{$product_promotion_start_date}\" df-data-timesalee=\"{$product_promotion_end_date}\">\n<span class=\"before\"><\/span><span class=\"ing\"><\/span><span class=\"after\"><\/span>\n<\/div>\n\t<div class=\"df-prl-desc\">\n\t\t<div class=\"df-prl-fadearea\">\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uceec\ub7ec\uce69 -->\n\t\t\t<!--#--><div class=\"xans-element- xans-product xans-product-colorchip-2 xans-product-colorchip xans-product-2 color color-custom-wrap\">\n<!--$--><!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span>\n<!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span><!--$-->\n<\/div>\n<!--#-->\n\n\t\t\t<!-- \uc0c1\ud488\uba85 -->\n\t\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-name {$product_name_display|display}\" style=\"{$product_name_css}\">{$product_name}<\/a>\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uc0c1\ud488\ud56d\ubaa9 -->\n\t\t\t<!--#--><ul class=\"xans-element- xans-product xans-product-listitem-2 xans-product-listitem xans-product-2 df-prl-listitem\">\n<!--$--><!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--$-->\n<\/ul>\n<!--#--><!-- \uc0c1\ud488\uc544\uc774\ucf58 --><div class=\"df-prl-icon\">{$soldout_icon} {$stock_icon} {$recommend_icon} {$new_icon} {$product_icons} {$pickup_icon} {$benefit_icons}<\/div>\n\n\t\t\t<!-- \uc635\uc158\ubcf4\uae30\u00b7\uc7a5\ubc14\uad6c\ub2c8\u00b7\uad00\uc2ec\uc0c1\ud488\u00b7\uc0c8\ucc3d\ubcf4\uae30 -->\n\t\t\t<div class=\"df-prl-status\">\n\t\t\t\t<span class=\"df-prl-status-item basket {$basket_icon|display}\">{$basket_icon}<\/span>\n\t\t\t\t<span class=\"df-prl-status-item wish {$list_wish_icon|display}\">{$list_wish_icon}<\/span>\n\t\t\t<\/div>\n\n\t\t<\/div>\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-fadeboxlink\"><\/a>\n\t<\/div>\n<\/div>\n<\/li>\n\t\t<!--@--><li class=\"df-prl-item\" id=\"anchorBoxId_{$product_no}\">\n<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d -->\n<div class=\"df-prl-box\">\n\t<span class=\"df-prl-label\"><\/span>\n\t<div class=\"df-prl-thumb\">\n\n\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uafb8\ubbf8\uae30\uc544\uc774\ucf58 \ud3ec\ud568 -->\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-thumb-link\" name=\"anchorBoxName_{$product_no}\"><img src=\"{$image_medium}\" id=\"{$image_medium_id}\" alt=\"{$seo_alt_tag}\" class=\"thumb\"><!--#--><span class=\"xans-element- xans-product xans-product-imagestyle-2 xans-product-imagestyle xans-product-2\">\n<span class=\"df-prl-decoicon {$icon_class_name}\" style=\"background-image:url('{$icon_url}');\"><\/span>\n<\/span>\n<!--#--><\/a>\n\n\t\t<!-- \uc88b\uc544\uc694 -->\n\t\t<span class=\"df-prl-like {$disp_likeprd_class} {$disp_likeprd_class|display}\">{$disp_likeprd_icon}{$disp_likeprd_count}<\/span>\n\n\t\t<!-- \ud560\uc778\uc728 -->\n\t\t<span class=\"df-prl-discountrate\">\n\t\t\t<span class=\"rate\"><\/span>%\n\t\t\t<span class=\"df-prl-data-custom displaynone\">{$product_custom}<\/span>\n\t\t\t<span class=\"df-prl-data-price displaynone\">{$product_price}<\/span>\n\t\t\t<span class=\"df-prl-data-sale displaynone\">{$prd_price_sale}<\/span>\n\t\t<\/span>\n\t<\/div>\n\t<div class=\"df-prl-timesale\" df-data-timesales=\"{$product_promotion_start_date}\" df-data-timesalee=\"{$product_promotion_end_date}\">\n<span class=\"before\"><\/span><span class=\"ing\"><\/span><span class=\"after\"><\/span>\n<\/div>\n\t<div class=\"df-prl-desc\">\n\t\t<div class=\"df-prl-fadearea\">\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uceec\ub7ec\uce69 -->\n\t\t\t<!--#--><div class=\"xans-element- xans-product xans-product-colorchip-2 xans-product-colorchip xans-product-2 color color-custom-wrap\">\n<!--$--><!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span>\n<!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span><!--$-->\n<\/div>\n<!--#-->\n\n\t\t\t<!-- \uc0c1\ud488\uba85 -->\n\t\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-name {$product_name_display|display}\" style=\"{$product_name_css}\">{$product_name}<\/a>\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uc0c1\ud488\ud56d\ubaa9 -->\n\t\t\t<!--#--><ul class=\"xans-element- xans-product xans-product-listitem-2 xans-product-listitem xans-product-2 df-prl-listitem\">\n<!--$--><!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--$-->\n<\/ul>\n<!--#--><!-- \uc0c1\ud488\uc544\uc774\ucf58 --><div class=\"df-prl-icon\">{$soldout_icon} {$stock_icon} {$recommend_icon} {$new_icon} {$product_icons} {$pickup_icon} {$benefit_icons}<\/div>\n\n\t\t\t<!-- \uc635\uc158\ubcf4\uae30\u00b7\uc7a5\ubc14\uad6c\ub2c8\u00b7\uad00\uc2ec\uc0c1\ud488\u00b7\uc0c8\ucc3d\ubcf4\uae30 -->\n\t\t\t<div class=\"df-prl-status\">\n\t\t\t\t<span class=\"df-prl-status-item basket {$basket_icon|display}\">{$basket_icon}<\/span>\n\t\t\t\t<span class=\"df-prl-status-item wish {$list_wish_icon|display}\">{$list_wish_icon}<\/span>\n\t\t\t<\/div>\n\n\t\t<\/div>\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-fadeboxlink\"><\/a>\n\t<\/div>\n<\/div>\n<\/li>\n<!--$-->\n\t<\/ul>\n<!-- \ub354\ubcf4\uae30 \ubc84\ud2bc --><!--#--><div class=\"xans-element- xans-product xans-product-listmore-2 xans-product-listmore xans-product-2 df-prl-more df-use-prl-more\">\n<a href=\"#none\" onclick=\"{$more_action}\" class=\"df-prl-more-link\">\n\t\t\t<span class=\"df-prl-more-page df-use-prl-more-page\">\n\t\t\t\t<!--$--><!--@--><span id=\"more_current_page_{$display_group}\" class=\"df-prl-more-page-current\">{$current_page}<\/span>\n\t\t\t\t<!--@--><span id=\"more_total_page_{$display_group}\" class=\"df-prl-more-page-total\">{$total_page}<\/span><!--$-->\n\t\t\t<\/span>\n\t\t<\/a>\n<\/div>\n<!--#-->\n<\/div>\n");
if (typeof($M) !== 'undefined') {
$M.sModule = "xans-product-listmain";
$M.iCount = 0;
$M.iCategoryNo = 0;
$M.iSortMethod = 0;
$M.init();
}
CAFE24.FRONT_XANS_TEMPLATE.setTemplate('xans-product-listmain-3', "<div class=\"xans-element- xans-product xans-product-listmain-3 xans-product-listmain xans-product-3 df-content-wrap df-prl-wrap df-prl-setup\">\n<!--\n\t\t$count = 12\n\t\t\u203b\ud55c\ubc88\uc5d0 \ud45c\uc2dc\ud560 \uc0c1\ud488\uc218\ub97c \uc124\uc815\ud560 \uc218 \uc788\uc2b5\ub2c8\ub2e4. \uac1c\uc218\uac00 \ub9ce\uc73c\uba74 \ubd80\ud558\uac00 \ubc1c\uc0dd\ud558\uba70 \uc18d\ub3c4\uac00 \ub290\ub824\uc9c8 \uc218 \uc788\uc2b5\ub2c8\ub2e4.\n\n\t\t$cache = yes\n\t\t\u203b\uce90\uc2dc\ub97c \uc124\uc815\ud558\uba74 \ub354\ubcf4\uae30 \ubc84\ud2bc\uc744 \ud074\ub9ad\ud55c \ub9cc\ud07c \uc7ac\uc811\uc18d\uc2dc \uae30\uc5b5\ud569\ub2c8\ub2e4. yes \ub610\ub294 no\ub85c \uc124\uc815\ud558\uc138\uc694.\n\n\t\t$moreview = yes\n\t\t\u203b\ud574\ub2f9 \ubcc0\uc218\ub294 \uc218\uc815\ud558\uc9c0\ub9c8\uc138\uc694. \ub9e4\ub274\uc5bc\uc744 \ucc38\uace0\ud558\uc5ec \ub354\ubcf4\uae30 \ubc84\ud2bc\uc758 \ud45c\uc2dc\uc5ec\ubd80\ub97c \uc124\uc815\ud558\uc2dc\uae30 \ubc14\ub78d\ub2c8\ub2e4.\n\t-->\n<div class=\"tit-product-main\">\n\t\t<h2><span>{$category_title_text}<\/span><\/h2>\n\t\t<span style=\"display: {$category_title_img_display};\"><img src=\"{$category_title_img}\" class=\"imgtitle\"><\/span>\n\t<\/div>\n<ul class=\"df-prl-items df-items-standby\">\n<!--$--><!--@--><li class=\"df-prl-item\" id=\"anchorBoxId_{$product_no}\">\n<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d -->\n<div class=\"df-prl-box\">\n\t<span class=\"df-prl-label\"><\/span>\n\t<div class=\"df-prl-thumb\">\n\n\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uafb8\ubbf8\uae30\uc544\uc774\ucf58 \ud3ec\ud568 -->\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-thumb-link\" name=\"anchorBoxName_{$product_no}\"><img src=\"{$image_medium}\" id=\"{$image_medium_id}\" alt=\"{$seo_alt_tag}\" class=\"thumb\"><!--#--><span class=\"xans-element- xans-product xans-product-imagestyle-3 xans-product-imagestyle xans-product-3\">\n<span class=\"df-prl-decoicon {$icon_class_name}\" style=\"background-image:url('{$icon_url}');\"><\/span>\n<\/span>\n<!--#--><\/a>\n\n\t\t<!-- \uc88b\uc544\uc694 -->\n\t\t<span class=\"df-prl-like {$disp_likeprd_class} {$disp_likeprd_class|display}\">{$disp_likeprd_icon}{$disp_likeprd_count}<\/span>\n\n\t\t<!-- \ud560\uc778\uc728 -->\n\t\t<span class=\"df-prl-discountrate\">\n\t\t\t<span class=\"rate\"><\/span>%\n\t\t\t<span class=\"df-prl-data-custom displaynone\">{$product_custom}<\/span>\n\t\t\t<span class=\"df-prl-data-price displaynone\">{$product_price}<\/span>\n\t\t\t<span class=\"df-prl-data-sale displaynone\">{$prd_price_sale}<\/span>\n\t\t<\/span>\n\t<\/div>\n\t<div class=\"df-prl-timesale\" df-data-timesales=\"{$product_promotion_start_date}\" df-data-timesalee=\"{$product_promotion_end_date}\">\n<span class=\"before\"><\/span><span class=\"ing\"><\/span><span class=\"after\"><\/span>\n<\/div>\n\t<div class=\"df-prl-desc\">\n\t\t<div class=\"df-prl-fadearea\">\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uceec\ub7ec\uce69 -->\n\t\t\t<!--#--><div class=\"xans-element- xans-product xans-product-colorchip-3 xans-product-colorchip xans-product-3 color color-custom-wrap\">\n<!--$--><!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span>\n<!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span><!--$-->\n<\/div>\n<!--#-->\n\n\t\t\t<!-- \uc0c1\ud488\uba85 -->\n\t\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-name {$product_name_display|display}\" style=\"{$product_name_css}\">{$product_name}<\/a>\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uc0c1\ud488\ud56d\ubaa9 -->\n\t\t\t<!--#--><ul class=\"xans-element- xans-product xans-product-listitem-3 xans-product-listitem xans-product-3 df-prl-listitem\">\n<!--$--><!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--$-->\n<\/ul>\n<!--#--><!-- \uc0c1\ud488\uc544\uc774\ucf58 --><div class=\"df-prl-icon\">{$soldout_icon} {$stock_icon} {$recommend_icon} {$new_icon} {$product_icons} {$pickup_icon} {$benefit_icons}<\/div>\n\n\t\t\t<!-- \uc635\uc158\ubcf4\uae30\u00b7\uc7a5\ubc14\uad6c\ub2c8\u00b7\uad00\uc2ec\uc0c1\ud488\u00b7\uc0c8\ucc3d\ubcf4\uae30 -->\n\t\t\t<div class=\"df-prl-status\">\n\t\t\t\t<span class=\"df-prl-status-item basket {$basket_icon|display}\">{$basket_icon}<\/span>\n\t\t\t\t<span class=\"df-prl-status-item wish {$list_wish_icon|display}\">{$list_wish_icon}<\/span>\n\t\t\t<\/div>\n\n\t\t<\/div>\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-fadeboxlink\"><\/a>\n\t<\/div>\n<\/div>\n<\/li>\n\t\t<!--@--><li class=\"df-prl-item\" id=\"anchorBoxId_{$product_no}\">\n<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d -->\n<div class=\"df-prl-box\">\n\t<span class=\"df-prl-label\"><\/span>\n\t<div class=\"df-prl-thumb\">\n\n\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uafb8\ubbf8\uae30\uc544\uc774\ucf58 \ud3ec\ud568 -->\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-thumb-link\" name=\"anchorBoxName_{$product_no}\"><img src=\"{$image_medium}\" id=\"{$image_medium_id}\" alt=\"{$seo_alt_tag}\" class=\"thumb\"><!--#--><span class=\"xans-element- xans-product xans-product-imagestyle-3 xans-product-imagestyle xans-product-3\">\n<span class=\"df-prl-decoicon {$icon_class_name}\" style=\"background-image:url('{$icon_url}');\"><\/span>\n<\/span>\n<!--#--><\/a>\n\n\t\t<!-- \uc88b\uc544\uc694 -->\n\t\t<span class=\"df-prl-like {$disp_likeprd_class} {$disp_likeprd_class|display}\">{$disp_likeprd_icon}{$disp_likeprd_count}<\/span>\n\n\t\t<!-- \ud560\uc778\uc728 -->\n\t\t<span class=\"df-prl-discountrate\">\n\t\t\t<span class=\"rate\"><\/span>%\n\t\t\t<span class=\"df-prl-data-custom displaynone\">{$product_custom}<\/span>\n\t\t\t<span class=\"df-prl-data-price displaynone\">{$product_price}<\/span>\n\t\t\t<span class=\"df-prl-data-sale displaynone\">{$prd_price_sale}<\/span>\n\t\t<\/span>\n\t<\/div>\n\t<div class=\"df-prl-timesale\" df-data-timesales=\"{$product_promotion_start_date}\" df-data-timesalee=\"{$product_promotion_end_date}\">\n<span class=\"before\"><\/span><span class=\"ing\"><\/span><span class=\"after\"><\/span>\n<\/div>\n\t<div class=\"df-prl-desc\">\n\t\t<div class=\"df-prl-fadearea\">\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uceec\ub7ec\uce69 -->\n\t\t\t<!--#--><div class=\"xans-element- xans-product xans-product-colorchip-3 xans-product-colorchip xans-product-3 color color-custom-wrap\">\n<!--$--><!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span>\n<!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span><!--$-->\n<\/div>\n<!--#-->\n\n\t\t\t<!-- \uc0c1\ud488\uba85 -->\n\t\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-name {$product_name_display|display}\" style=\"{$product_name_css}\">{$product_name}<\/a>\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uc0c1\ud488\ud56d\ubaa9 -->\n\t\t\t<!--#--><ul class=\"xans-element- xans-product xans-product-listitem-3 xans-product-listitem xans-product-3 df-prl-listitem\">\n<!--$--><!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--$-->\n<\/ul>\n<!--#--><!-- \uc0c1\ud488\uc544\uc774\ucf58 --><div class=\"df-prl-icon\">{$soldout_icon} {$stock_icon} {$recommend_icon} {$new_icon} {$product_icons} {$pickup_icon} {$benefit_icons}<\/div>\n\n\t\t\t<!-- \uc635\uc158\ubcf4\uae30\u00b7\uc7a5\ubc14\uad6c\ub2c8\u00b7\uad00\uc2ec\uc0c1\ud488\u00b7\uc0c8\ucc3d\ubcf4\uae30 -->\n\t\t\t<div class=\"df-prl-status\">\n\t\t\t\t<span class=\"df-prl-status-item basket {$basket_icon|display}\">{$basket_icon}<\/span>\n\t\t\t\t<span class=\"df-prl-status-item wish {$list_wish_icon|display}\">{$list_wish_icon}<\/span>\n\t\t\t<\/div>\n\n\t\t<\/div>\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-fadeboxlink\"><\/a>\n\t<\/div>\n<\/div>\n<\/li>\n<!--$-->\n\t<\/ul>\n<!-- \ub354\ubcf4\uae30 \ubc84\ud2bc --><!--#--><div class=\"xans-element- xans-product xans-product-listmore-3 xans-product-listmore xans-product-3 df-prl-more df-use-prl-more\">\n<a href=\"#none\" onclick=\"{$more_action}\" class=\"df-prl-more-link\">\n\t\t\t<span class=\"df-prl-more-page df-use-prl-more-page\">\n\t\t\t\t<!--$--><!--@--><span id=\"more_current_page_{$display_group}\" class=\"df-prl-more-page-current\">{$current_page}<\/span>\n\t\t\t\t<!--@--><span id=\"more_total_page_{$display_group}\" class=\"df-prl-more-page-total\">{$total_page}<\/span><!--$-->\n\t\t\t<\/span>\n\t\t<\/a>\n<\/div>\n<!--#-->\n<\/div>\n");
if (typeof($M) !== 'undefined') {
$M.sModule = "xans-product-listmain";
$M.iCount = 0;
$M.iCategoryNo = 0;
$M.iSortMethod = 0;
$M.init();
}
CAFE24.FRONT_XANS_TEMPLATE.setTemplate('xans-product-listmain-4', "<div class=\"xans-element- xans-product xans-product-listmain-4 xans-product-listmain xans-product-4 df-content-wrap df-prl-wrap df-prl-setup\">\n<!--\n\t\t$count = 12\n\t\t\u203b\ud55c\ubc88\uc5d0 \ud45c\uc2dc\ud560 \uc0c1\ud488\uc218\ub97c \uc124\uc815\ud560 \uc218 \uc788\uc2b5\ub2c8\ub2e4. \uac1c\uc218\uac00 \ub9ce\uc73c\uba74 \ubd80\ud558\uac00 \ubc1c\uc0dd\ud558\uba70 \uc18d\ub3c4\uac00 \ub290\ub824\uc9c8 \uc218 \uc788\uc2b5\ub2c8\ub2e4.\n\n\t\t$cache = yes\n\t\t\u203b\uce90\uc2dc\ub97c \uc124\uc815\ud558\uba74 \ub354\ubcf4\uae30 \ubc84\ud2bc\uc744 \ud074\ub9ad\ud55c \ub9cc\ud07c \uc7ac\uc811\uc18d\uc2dc \uae30\uc5b5\ud569\ub2c8\ub2e4. yes \ub610\ub294 no\ub85c \uc124\uc815\ud558\uc138\uc694.\n\n\t\t$moreview = yes\n\t\t\u203b\ud574\ub2f9 \ubcc0\uc218\ub294 \uc218\uc815\ud558\uc9c0\ub9c8\uc138\uc694. \ub9e4\ub274\uc5bc\uc744 \ucc38\uace0\ud558\uc5ec \ub354\ubcf4\uae30 \ubc84\ud2bc\uc758 \ud45c\uc2dc\uc5ec\ubd80\ub97c \uc124\uc815\ud558\uc2dc\uae30 \ubc14\ub78d\ub2c8\ub2e4.\n\t-->\n<div class=\"tit-product-main\">\n\t\t<h2><span>{$category_title_text}<\/span><\/h2>\n\t\t<span style=\"display: {$category_title_img_display};\"><img src=\"{$category_title_img}\" class=\"imgtitle\"><\/span>\n\t<\/div>\n<ul class=\"df-prl-items df-items-standby\">\n<!--$--><!--@--><li class=\"df-prl-item\" id=\"anchorBoxId_{$product_no}\">\n<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d -->\n<div class=\"df-prl-box\">\n\t<span class=\"df-prl-label\"><\/span>\n\t<div class=\"df-prl-thumb\">\n\n\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uafb8\ubbf8\uae30\uc544\uc774\ucf58 \ud3ec\ud568 -->\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-thumb-link\" name=\"anchorBoxName_{$product_no}\"><img src=\"{$image_medium}\" id=\"{$image_medium_id}\" alt=\"{$seo_alt_tag}\" class=\"thumb\"><!--#--><span class=\"xans-element- xans-product xans-product-imagestyle-4 xans-product-imagestyle xans-product-4\">\n<span class=\"df-prl-decoicon {$icon_class_name}\" style=\"background-image:url('{$icon_url}');\"><\/span>\n<\/span>\n<!--#--><\/a>\n\n\t\t<!-- \uc88b\uc544\uc694 -->\n\t\t<span class=\"df-prl-like {$disp_likeprd_class} {$disp_likeprd_class|display}\">{$disp_likeprd_icon}{$disp_likeprd_count}<\/span>\n\n\t\t<!-- \ud560\uc778\uc728 -->\n\t\t<span class=\"df-prl-discountrate\">\n\t\t\t<span class=\"rate\"><\/span>%\n\t\t\t<span class=\"df-prl-data-custom displaynone\">{$product_custom}<\/span>\n\t\t\t<span class=\"df-prl-data-price displaynone\">{$product_price}<\/span>\n\t\t\t<span class=\"df-prl-data-sale displaynone\">{$prd_price_sale}<\/span>\n\t\t<\/span>\n\t<\/div>\n\t<div class=\"df-prl-timesale\" df-data-timesales=\"{$product_promotion_start_date}\" df-data-timesalee=\"{$product_promotion_end_date}\">\n<span class=\"before\"><\/span><span class=\"ing\"><\/span><span class=\"after\"><\/span>\n<\/div>\n\t<div class=\"df-prl-desc\">\n\t\t<div class=\"df-prl-fadearea\">\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uceec\ub7ec\uce69 -->\n\t\t\t<!--#--><div class=\"xans-element- xans-product xans-product-colorchip-4 xans-product-colorchip xans-product-4 color color-custom-wrap\">\n<!--$--><!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span>\n<!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span><!--$-->\n<\/div>\n<!--#-->\n\n\t\t\t<!-- \uc0c1\ud488\uba85 -->\n\t\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-name {$product_name_display|display}\" style=\"{$product_name_css}\">{$product_name}<\/a>\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uc0c1\ud488\ud56d\ubaa9 -->\n\t\t\t<!--#--><ul class=\"xans-element- xans-product xans-product-listitem-4 xans-product-listitem xans-product-4 df-prl-listitem\">\n<!--$--><!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--$-->\n<\/ul>\n<!--#--><!-- \uc0c1\ud488\uc544\uc774\ucf58 --><div class=\"df-prl-icon\">{$soldout_icon} {$stock_icon} {$recommend_icon} {$new_icon} {$product_icons} {$pickup_icon} {$benefit_icons}<\/div>\n\n\t\t\t<!-- \uc635\uc158\ubcf4\uae30\u00b7\uc7a5\ubc14\uad6c\ub2c8\u00b7\uad00\uc2ec\uc0c1\ud488\u00b7\uc0c8\ucc3d\ubcf4\uae30 -->\n\t\t\t<div class=\"df-prl-status\">\n\t\t\t\t<span class=\"df-prl-status-item basket {$basket_icon|display}\">{$basket_icon}<\/span>\n\t\t\t\t<span class=\"df-prl-status-item wish {$list_wish_icon|display}\">{$list_wish_icon}<\/span>\n\t\t\t<\/div>\n\n\t\t<\/div>\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-fadeboxlink\"><\/a>\n\t<\/div>\n<\/div>\n<\/li>\n\t\t<!--@--><li class=\"df-prl-item\" id=\"anchorBoxId_{$product_no}\">\n<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d -->\n<div class=\"df-prl-box\">\n\t<span class=\"df-prl-label\"><\/span>\n\t<div class=\"df-prl-thumb\">\n\n\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uafb8\ubbf8\uae30\uc544\uc774\ucf58 \ud3ec\ud568 -->\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-thumb-link\" name=\"anchorBoxName_{$product_no}\"><img src=\"{$image_medium}\" id=\"{$image_medium_id}\" alt=\"{$seo_alt_tag}\" class=\"thumb\"><!--#--><span class=\"xans-element- xans-product xans-product-imagestyle-4 xans-product-imagestyle xans-product-4\">\n<span class=\"df-prl-decoicon {$icon_class_name}\" style=\"background-image:url('{$icon_url}');\"><\/span>\n<\/span>\n<!--#--><\/a>\n\n\t\t<!-- \uc88b\uc544\uc694 -->\n\t\t<span class=\"df-prl-like {$disp_likeprd_class} {$disp_likeprd_class|display}\">{$disp_likeprd_icon}{$disp_likeprd_count}<\/span>\n\n\t\t<!-- \ud560\uc778\uc728 -->\n\t\t<span class=\"df-prl-discountrate\">\n\t\t\t<span class=\"rate\"><\/span>%\n\t\t\t<span class=\"df-prl-data-custom displaynone\">{$product_custom}<\/span>\n\t\t\t<span class=\"df-prl-data-price displaynone\">{$product_price}<\/span>\n\t\t\t<span class=\"df-prl-data-sale displaynone\">{$prd_price_sale}<\/span>\n\t\t<\/span>\n\t<\/div>\n\t<div class=\"df-prl-timesale\" df-data-timesales=\"{$product_promotion_start_date}\" df-data-timesalee=\"{$product_promotion_end_date}\">\n<span class=\"before\"><\/span><span class=\"ing\"><\/span><span class=\"after\"><\/span>\n<\/div>\n\t<div class=\"df-prl-desc\">\n\t\t<div class=\"df-prl-fadearea\">\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uceec\ub7ec\uce69 -->\n\t\t\t<!--#--><div class=\"xans-element- xans-product xans-product-colorchip-4 xans-product-colorchip xans-product-4 color color-custom-wrap\">\n<!--$--><!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span>\n<!--@--><span class=\"chips\" style=\"background-color:{$color}\" color_no=\"{$color_no}\" displaygroup=\"{$display_group}\"><\/span><!--$-->\n<\/div>\n<!--#-->\n\n\t\t\t<!-- \uc0c1\ud488\uba85 -->\n\t\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-name {$product_name_display|display}\" style=\"{$product_name_css}\">{$product_name}<\/a>\n\n\t\t\t<!-- \uae30\ubcf8 \uc0c1\ud488\ubaa9\ub85d \uc0c1\ud488\ud56d\ubaa9 -->\n\t\t\t<!--#--><ul class=\"xans-element- xans-product xans-product-listitem-4 xans-product-listitem xans-product-4 df-prl-listitem\">\n<!--$--><!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--@--><li class=\"df-prl-listitem-cell {$column_name} {$item_display|display}\">\n<strong class=\"df-prl-title {$item_title_display|display}\">{$item_title} :<\/strong> {$item_content}<\/li>\n<!--$-->\n<\/ul>\n<!--#--><!-- \uc0c1\ud488\uc544\uc774\ucf58 --><div class=\"df-prl-icon\">{$soldout_icon} {$stock_icon} {$recommend_icon} {$new_icon} {$product_icons} {$pickup_icon} {$benefit_icons}<\/div>\n\n\t\t\t<!-- \uc635\uc158\ubcf4\uae30\u00b7\uc7a5\ubc14\uad6c\ub2c8\u00b7\uad00\uc2ec\uc0c1\ud488\u00b7\uc0c8\ucc3d\ubcf4\uae30 -->\n\t\t\t<div class=\"df-prl-status\">\n\t\t\t\t<span class=\"df-prl-status-item basket {$basket_icon|display}\">{$basket_icon}<\/span>\n\t\t\t\t<span class=\"df-prl-status-item wish {$list_wish_icon|display}\">{$list_wish_icon}<\/span>\n\t\t\t<\/div>\n\n\t\t<\/div>\n\t\t<a href=\"\/product\/detail.html{$param}\" class=\"df-prl-fadeboxlink\"><\/a>\n\t<\/div>\n<\/div>\n<\/li>\n<!--$-->\n\t<\/ul>\n<!-- \ub354\ubcf4\uae30 \ubc84\ud2bc --><!--#--><div class=\"xans-element- xans-product xans-product-listmore-4 xans-product-listmore xans-product-4 df-prl-more df-use-prl-more\">\n<a href=\"#none\" onclick=\"{$more_action}\" class=\"df-prl-more-link\">\n\t\t\t<span class=\"df-prl-more-page df-use-prl-more-page\">\n\t\t\t\t<!--$--><!--@--><span id=\"more_current_page_{$display_group}\" class=\"df-prl-more-page-current\">{$current_page}<\/span>\n\t\t\t\t<!--@--><span id=\"more_total_page_{$display_group}\" class=\"df-prl-more-page-total\">{$total_page}<\/span><!--$-->\n\t\t\t<\/span>\n\t\t<\/a>\n<\/div>\n<!--#-->\n<\/div>\n");
if (typeof($M) !== 'undefined') {
$M.sModule = "xans-product-listmain";
$M.iCount = 0;
$M.iCategoryNo = 0;
$M.iSortMethod = 0;
$M.init();
}
var bIsUseSpread = false;
var sIsSecret = false;
var iBoardNo = "4";
var bIsUseSpread = false;
var sIsSecret = false;
var iBoardNo = "1";
var aLogData = {"log_server1":"eclog2-260.cafe24.com","log_server2":"elg-db-svcm-203.cafe24.com","mid":"ekdlqjtntks","stype":"e","domain":"","shop_no":1,"lang":"ko_KR","ver":2,"hash":"e2ca3c9e065de8de49b330f47bf7a69f","ca":"cfa-js.cafe24.com\/cfa.js","etc":""};
var sMileageName = '적립금';
var sMileageUnit = '[:PRICE:]원';
var sDepositName = '예치금';
var sDepositUnit = '원';
var EC_ASYNC_LIVELINKON_ID = '';
; (function() {
var setPcVersionCookie = function() {
$.ajax({
url: '/exec/front/manage/ajaxcookie',
async: false
});
};
if (typeof window.isPCver === 'function') {
var isPCverOld = window.isPCver;
window.isPCver = function() {
setPcVersionCookie();
isPCverOld();
};
}
}());
if (EC$('[async_section=before]').length > 0) {
EC$('[async_section=before]').addClass('displaynone');
}
CAFE24.APPSCRIPT_ASSIGN_DATA = CAFE24.APPSCRIPT_ASSIGN_DATA || [{'src':'https://simple.happytalkio.com/storage/NAS/cafe24_shop/ek/ekdlqjtntks/1/kakao_plus_friend.js?v=1618980714&vs=20210421135153.1&client_id=gdc7WwhtIx4htbBH2iGjuB'},{'src':'https://app4you.cafe24.com/SmartPopup/tunnel/scriptTags?vs=20200724125106.1&client_id=AyPifbe9TEq8i4fmvfUgaZ'}];
CAFE24.APPSCRIPT_SDK_DATA = CAFE24.APPSCRIPT_SDK_DATA || ['application','order','customer','product','store','community','notification','personal','privacy','promotion','salesreport','category','design','supply'];
var EC_APPSCRIPT_ASSIGN_DATA = CAFE24.getDeprecatedNamespace('EC_APPSCRIPT_ASSIGN_DATA');
var EC_APPSCRIPT_SDK_DATA = CAFE24.getDeprecatedNamespace('EC_APPSCRIPT_SDK_DATA');
</script></body></html>
