const dramas=[
    "전어",
    "홍합",
    "방어",
    "해물탕",

];
console.log("해물탕".includes("물"));